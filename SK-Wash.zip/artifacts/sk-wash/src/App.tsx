import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Navbar } from '@/components/Navbar';
import { Hero } from '@/components/Hero';
import { About } from '@/components/About';
import { Services } from '@/components/Services';
import { Pricing } from '@/components/Pricing';
import { WhyChooseUs } from '@/components/WhyChooseUs';
import { BookingForm } from '@/components/BookingForm';
import { Footer } from '@/components/Footer';

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen bg-background text-foreground flex flex-col selection:bg-white/20">
        <Navbar />
        
        <main className="flex-1">
          <Hero />
          <About />
          <Services />
          <WhyChooseUs />
          <Pricing />
          <BookingForm />
        </main>
        
        <Footer />
      </div>
    </QueryClientProvider>
  );
}

export default App;
