import { motion } from 'framer-motion';
import heroImg from '@assets/generated_images/hero-wash.jpg';

export function Hero() {
  return (
    <section className="relative h-[100dvh] min-h-[640px] w-full flex items-center justify-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 w-full h-full">
        <motion.img
          initial={{ scale: 1.08 }}
          animate={{ scale: 1 }}
          transition={{ duration: 12, ease: 'easeOut' }}
          src={heroImg}
          className="absolute inset-0 w-full h-full object-cover"
          alt="Luxury Car Wash"
        />
        {/* Dark gradient layers */}
        <div className="absolute inset-0 bg-black/55 z-10" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-background z-10" />
        {/* Blue tint at bottom */}
        <div className="absolute bottom-0 left-0 right-0 h-1/3 bg-gradient-to-t from-blue-950/20 to-transparent z-10" />
      </div>

      {/* Content */}
      <div className="container relative z-20 mx-auto px-6 flex flex-col items-center text-center">
        {/* Eyebrow tag */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="flex items-center gap-3 mb-8"
        >
          <div className="h-[1px] w-8 bg-blue-500/60" />
          <span className="text-[11px] uppercase tracking-[0.35em] text-blue-400">Mobile Car Wash — Comes To You</span>
          <div className="h-[1px] w-8 bg-blue-500/60" />
        </motion.div>

        {/* Main heading */}
        <motion.h1
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.4 }}
          className="text-6xl sm:text-7xl md:text-8xl lg:text-9xl font-bold font-serif text-white tracking-tighter leading-none mb-8"
        >
          PREMIUM
          <br />
          <span className="text-gradient-silver italic">CAR WASH</span>
        </motion.h1>

        {/* Subtext */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.65 }}
          className="text-base md:text-lg text-gray-400 max-w-xl mx-auto font-light mb-12 tracking-wide"
        >
          Professional car cleaning brought to your location.<br className="hidden md:block" />
          Precision, care, and a showroom finish — every time.
        </motion.p>

        {/* CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.85 }}
          className="flex flex-col sm:flex-row items-center gap-4"
        >
          <a
            href="#booking"
            className="px-10 py-4 text-white text-xs uppercase tracking-[0.25em] font-bold transition-all duration-300 hover:opacity-90 hover:shadow-[0_8px_40px_rgba(37,99,235,0.5)] min-w-[210px] text-center"
            style={{
              background: 'linear-gradient(135deg, #1a4fd8 0%, #2563eb 50%, #1e40af 100%)',
              boxShadow: '0 4px 30px rgba(37, 99, 235, 0.35)',
            }}
          >
            Book Your Wash
          </a>
          <a
            href="#services"
            className="px-10 py-4 bg-transparent border border-white/25 text-white text-xs uppercase tracking-[0.25em] font-semibold hover:bg-white/8 hover:border-white/50 transition-all duration-300 min-w-[210px] text-center"
          >
            View Services
          </a>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.8, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2"
      >
        <span className="text-[9px] uppercase tracking-[0.3em] text-white/30">Scroll</span>
        <div className="w-[1px] h-10 bg-gradient-to-b from-white/40 to-transparent" />
      </motion.div>
    </section>
  );
}
