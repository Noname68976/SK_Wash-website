import { motion } from 'framer-motion';
import { MapPin, Sparkles, ShieldCheck, Clock } from 'lucide-react';
import sleekCarImg from '@assets/generated_images/sleek-car.jpg';

const reasons = [
  {
    icon: <MapPin size={20} />,
    title: "Mobile Service",
    description: "We come to your home, office, or preferred location — ultimate convenience."
  },
  {
    icon: <Sparkles size={20} />,
    title: "Quality Products",
    description: "Premium, pH-balanced automotive detailing products to protect your paint and finish."
  },
  {
    icon: <ShieldCheck size={20} />,
    title: "Attention To Detail",
    description: "Every crevice, emblem, and seam is carefully cleaned for a true showroom finish."
  },
  {
    icon: <Clock size={20} />,
    title: "Convenient Booking",
    description: "Simple scheduling — pick a time, we handle everything else."
  }
];

export function WhyChooseUs() {
  return (
    <section id="why-us" className="py-28 bg-[#020202] relative border-t border-white/5 overflow-hidden">
      {/* Blue glow */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-900/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-16 xl:gap-24 items-center">

          {/* Image side */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="w-full lg:w-1/2 relative"
          >
            <div className="relative aspect-square max-w-md mx-auto lg:mx-0 overflow-hidden">
              {/* Blue overlay */}
              <div className="absolute inset-0 bg-gradient-to-br from-blue-900/30 to-transparent z-10 mix-blend-overlay" />
              <img
                src={sleekCarImg}
                alt="Sleek clean car exterior"
                className="w-full h-full object-cover grayscale-[20%] contrast-[1.1]"
              />
              {/* Decorative frame */}
              <div className="absolute inset-4 border border-blue-500/20 z-20" />
              {/* Corner accents */}
              <div className="absolute top-4 left-4 w-6 h-6 border-t-2 border-l-2 border-blue-500/60 z-30" />
              <div className="absolute bottom-4 right-4 w-6 h-6 border-b-2 border-r-2 border-blue-500/60 z-30" />
            </div>
          </motion.div>

          {/* Content side */}
          <div className="w-full lg:w-1/2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="mb-12"
            >
              <p className="text-xs uppercase tracking-[0.35em] text-blue-400 mb-4">Why SK Wash</p>
              <h2 className="text-4xl md:text-5xl font-serif text-white mb-6 leading-tight">
                Beyond a <span className="italic text-gray-400">Simple Wash</span>
              </h2>
              <p className="text-gray-500 text-base leading-relaxed">
                Your vehicle deserves the same level of care and precision that went into building it.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
              {reasons.map((reason, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1, duration: 0.5 }}
                  className="group"
                >
                  <div
                    className="w-11 h-11 flex items-center justify-center mb-4 transition-all duration-300 group-hover:shadow-[0_0_20px_rgba(37,99,235,0.4)]"
                    style={{
                      background: 'linear-gradient(135deg, rgba(37,99,235,0.15) 0%, rgba(37,99,235,0.05) 100%)',
                      border: '1px solid rgba(37,99,235,0.25)',
                      color: '#60a5fa',
                    }}
                  >
                    {reason.icon}
                  </div>
                  <h4 className="text-base font-serif text-white mb-2 group-hover:text-blue-200 transition-colors">{reason.title}</h4>
                  <p className="text-sm text-gray-600 leading-relaxed">{reason.description}</p>
                </motion.div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
