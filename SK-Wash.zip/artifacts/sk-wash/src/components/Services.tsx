import { motion } from 'framer-motion';

const services = [
  {
    number: "01",
    title: "Basic Exterior Wash",
    items: ["Foam wash", "Hand wash", "Wheel cleaning", "Exterior finish"],
  },
  {
    number: "02",
    title: "Interior Clean",
    items: ["Vacuum cleaning", "Interior wipe down", "Basic refresh", "Glass cleaning"],
  },
  {
    number: "03",
    title: "Complete Basic Package",
    items: ["Exterior foam wash", "Interior vacuum", "Wheel cleaning", "Full wipe down"],
  }
];

export function Services() {
  return (
    <section id="services" className="py-28 bg-[#050505] relative border-t border-white/5">
      {/* Blue ambient glow */}
      <div className="absolute bottom-0 right-0 w-[600px] h-[400px] bg-blue-600/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-20"
        >
          <p className="text-xs uppercase tracking-[0.35em] text-blue-400 mb-4">Our Expertise</p>
          <h2 className="text-4xl md:text-6xl font-serif text-white">
            Signature <span className="italic text-gray-400">Services</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-white/5">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group relative bg-[#050505] p-10 hover:bg-[#0a0f1a] transition-colors duration-500 overflow-hidden"
            >
              {/* Blue top accent line on hover */}
              <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-blue-600 via-blue-400 to-transparent scale-x-0 group-hover:scale-x-100 transition-transform duration-700 origin-left" />
              {/* Subtle blue glow on hover */}
              <div className="absolute inset-0 bg-blue-600/0 group-hover:bg-blue-600/5 transition-colors duration-500 pointer-events-none" />

              <span className="text-5xl font-serif text-white/10 group-hover:text-white/20 transition-colors duration-500 select-none block mb-8">
                {service.number}
              </span>

              <h4 className="text-xl font-serif text-white mb-6 group-hover:text-blue-200 transition-colors duration-300">
                {service.title}
              </h4>

              <ul className="space-y-3">
                {service.items.map((item, i) => (
                  <li key={i} className="flex items-center text-sm text-gray-500 group-hover:text-gray-400 transition-colors">
                    <div className="w-4 h-[1px] bg-blue-500/40 mr-3 group-hover:bg-blue-400/70 transition-colors" />
                    {item}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
