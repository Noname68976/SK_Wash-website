import { useState } from 'react';
import { motion } from 'framer-motion';
import emailjs from '@emailjs/browser';

const inputClass =
  "w-full bg-transparent border-b border-white/15 pb-3 text-white text-sm focus:outline-none focus:border-blue-500 transition-colors placeholder:text-gray-700";
const selectClass =
  "w-full bg-transparent border-b border-white/15 pb-3 text-white text-sm focus:outline-none focus:border-blue-500 transition-colors appearance-none cursor-pointer";
const labelClass = "text-[10px] uppercase tracking-[0.25em] text-gray-600 block mb-2";

interface FormData {
  customerName: string;
  phone: string;
  vehicleType: string;
  serviceNeeded: string;
  preferredDate: string;
  location: string;
}

export function BookingForm() {
  const [submitted, setSubmitted] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState<FormData>({
    customerName: '',
    phone: '',
    vehicleType: '',
    serviceNeeded: '',
    preferredDate: '',
    location: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    setError(null);

    try {
      await emailjs.send(
        import.meta.env.VITE_EMAILJS_SERVICE_ID,
        import.meta.env.VITE_EMAILJS_TEMPLATE_ID,
        {
          customer_name: form.customerName,
          phone: form.phone,
          vehicle_type: form.vehicleType,
          service_needed: form.serviceNeeded,
          preferred_date: form.preferredDate,
          location: form.location,
          to_email: 'pbx1pb65@gmail.com',
          reply_to: 'pbx1pb65@gmail.com',
        },
        import.meta.env.VITE_EMAILJS_PUBLIC_KEY,
      );
      setSubmitted(true);
    } catch (err) {
      console.error('EmailJS error:', err);
      setError('Something went wrong sending your request. Please try calling us directly on 0477 204 010.');
    } finally {
      setSending(false);
    }
  };

  return (
    <section id="booking" className="py-28 md:py-36 bg-background relative border-t border-white/5 overflow-hidden">
      {/* Ambient blue glow */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-blue-900/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <p className="text-xs uppercase tracking-[0.35em] text-blue-400 mb-4">Get Started</p>
            <h2 className="text-4xl md:text-6xl font-serif text-white mb-4">Request a Booking</h2>
            <p className="text-gray-500 text-sm">Fill out the form and we will contact you to confirm your appointment.</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.15 }}
            className="relative"
            style={{
              background: 'linear-gradient(145deg, #0a0e1a 0%, #080808 100%)',
              border: '1px solid rgba(255,255,255,0.08)',
              boxShadow: '0 0 80px rgba(37,99,235,0.05)',
            }}
          >
            {/* Top blue line */}
            <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-blue-500/60 to-transparent" />

            <div className="p-8 md:p-14">
              {submitted ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center py-16"
                >
                  <div
                    className="w-16 h-16 flex items-center justify-center mx-auto mb-6"
                    style={{
                      background: 'rgba(37,99,235,0.1)',
                      border: '1px solid rgba(37,99,235,0.3)',
                      boxShadow: '0 0 30px rgba(37,99,235,0.2)',
                    }}
                  >
                    <svg className="w-7 h-7 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <h3 className="text-2xl font-serif text-white mb-4">Request Received</h3>
                  <p className="text-gray-400 max-w-md mx-auto leading-relaxed">
                    Thanks for contacting SK Wash. We will get back to you to confirm your booking.
                  </p>
                  <button
                    onClick={() => { setSubmitted(false); setForm({ customerName: '', phone: '', vehicleType: '', serviceNeeded: '', preferredDate: '', location: '' }); }}
                    className="mt-10 px-8 py-3 border border-white/15 text-white text-xs uppercase tracking-[0.2em] hover:border-blue-500/50 hover:text-blue-300 transition-all"
                  >
                    Submit Another
                  </button>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-10">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    <div>
                      <label className={labelClass}>Customer Name</label>
                      <input
                        required name="customerName" type="text"
                        value={form.customerName} onChange={handleChange}
                        className={inputClass} placeholder="John Doe"
                      />
                    </div>
                    <div>
                      <label className={labelClass}>Phone Number</label>
                      <input
                        required name="phone" type="tel"
                        value={form.phone} onChange={handleChange}
                        className={inputClass} placeholder="0400 000 000"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    <div>
                      <label className={labelClass}>Vehicle Type</label>
                      <select required name="vehicleType" value={form.vehicleType} onChange={handleChange} className={selectClass}>
                        <option value="" disabled className="text-black">Select vehicle...</option>
                        <option value="Sedan" className="text-black">Sedan</option>
                        <option value="SUV" className="text-black">SUV</option>
                        <option value="Hatchback" className="text-black">Hatchback</option>
                        <option value="Ute / Truck" className="text-black">Ute / Truck</option>
                        <option value="Van" className="text-black">Van</option>
                        <option value="Other" className="text-black">Other</option>
                      </select>
                    </div>
                    <div>
                      <label className={labelClass}>Service Needed</label>
                      <select required name="serviceNeeded" value={form.serviceNeeded} onChange={handleChange} className={selectClass}>
                        <option value="" disabled className="text-black">Select service...</option>
                        <option value="Basic Exterior Wash" className="text-black">Basic Exterior Wash</option>
                        <option value="Interior Clean" className="text-black">Interior Clean</option>
                        <option value="Complete Basic Package" className="text-black">Complete Basic Package</option>
                        <option value="Basic Wash ($35)" className="text-black">Basic Wash ($35)</option>
                        <option value="Premium Wash ($50)" className="text-black">Premium Wash ($50)</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    <div>
                      <label className={labelClass}>Preferred Date</label>
                      <input
                        required name="preferredDate" type="date"
                        value={form.preferredDate} onChange={handleChange}
                        className={`${inputClass} [&::-webkit-calendar-picker-indicator]:filter [&::-webkit-calendar-picker-indicator]:invert`}
                      />
                    </div>
                    <div>
                      <label className={labelClass}>Location / Address</label>
                      <input
                        required name="location" type="text"
                        value={form.location} onChange={handleChange}
                        className={inputClass} placeholder="123 Example St, City"
                      />
                    </div>
                  </div>

                  {error && (
                    <p className="text-red-400 text-sm text-center border border-red-500/20 py-3 px-4 bg-red-900/10">
                      {error}
                    </p>
                  )}

                  <div className="pt-4">
                    <button
                      type="submit"
                      disabled={sending}
                      className="w-full py-5 text-white text-xs uppercase tracking-[0.25em] font-bold transition-all duration-300 hover:opacity-90 hover:shadow-[0_8px_40px_rgba(37,99,235,0.5)] disabled:opacity-50 disabled:cursor-not-allowed"
                      style={{
                        background: 'linear-gradient(135deg, #1a4fd8 0%, #2563eb 50%, #1e40af 100%)',
                        boxShadow: '0 4px 30px rgba(37, 99, 235, 0.35)',
                      }}
                    >
                      {sending ? 'Sending...' : 'Submit Booking Request'}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
