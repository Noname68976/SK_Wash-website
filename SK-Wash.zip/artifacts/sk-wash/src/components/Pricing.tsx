import { motion } from 'framer-motion';
import { Check } from 'lucide-react';

export function Pricing() {
  return (
    <section id="pricing" className="py-28 md:py-36 bg-background relative overflow-hidden">
      {/* Ambient glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-blue-900/10 rounded-full blur-[140px] pointer-events-none" />

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-xs uppercase tracking-[0.35em] text-blue-400 mb-4"
          >
            Investment
          </motion.p>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-6xl font-serif text-white mb-4"
          >
            Transparent <span className="italic text-gray-400">Pricing</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.15 }}
            className="text-gray-500 max-w-sm mx-auto text-sm"
          >
            Premium service, honest pricing — no hidden fees, ever.
          </motion.p>
        </div>

        <div className="max-w-3xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">
          {/* Basic Package */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="group relative bg-[#080808] border border-white/10 p-10 flex flex-col hover:border-white/20 transition-colors duration-300"
          >
            <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-white/20 to-transparent" />

            <p className="text-xs uppercase tracking-[0.3em] text-gray-600 mb-6">Entry</p>
            <h3 className="text-2xl font-serif text-white mb-3">Basic Wash</h3>
            <div className="flex items-end gap-2 mb-10 pb-8 border-b border-white/10">
              <span className="text-6xl font-light text-white tracking-tight">$35</span>
              <span className="text-gray-600 mb-2 text-sm">per visit</span>
            </div>

            <ul className="space-y-4 mb-10 flex-1">
              {['Exterior wash', 'Foam wash', 'Wheel clean', 'Tire dressing'].map((feature, i) => (
                <li key={i} className="flex items-center text-gray-400 text-sm gap-3">
                  <Check size={14} className="text-white/40 shrink-0" />
                  {feature}
                </li>
              ))}
            </ul>

            <a
              href="#booking"
              className="block w-full py-4 text-center border border-white/20 text-white text-xs uppercase tracking-[0.2em] font-semibold hover:bg-white hover:text-black transition-all duration-300"
            >
              Book Basic
            </a>
          </motion.div>

          {/* Premium Package */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="group relative flex flex-col p-10"
            style={{
              background: 'linear-gradient(145deg, #0d1b2a 0%, #0a1020 60%, #060c18 100%)',
              boxShadow: '0 0 60px rgba(30, 80, 200, 0.15), inset 0 1px 0 rgba(100, 160, 255, 0.15)',
              border: '1px solid rgba(60, 120, 255, 0.25)',
            }}
          >
            {/* Blue top glow line */}
            <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-blue-500 to-transparent" />
            {/* Corner accent */}
            <div className="absolute top-0 right-0 w-20 h-20 bg-blue-600/10 blur-2xl" />

            <div className="flex items-center justify-between mb-6">
              <p className="text-xs uppercase tracking-[0.3em] text-blue-400">Most Popular</p>
              <span className="text-[10px] px-3 py-1 bg-blue-600/20 text-blue-300 border border-blue-500/30 uppercase tracking-widest">
                Best Value
              </span>
            </div>

            <h3 className="text-2xl font-serif text-white mb-3">Premium Wash</h3>
            <div className="flex items-end gap-2 mb-10 pb-8 border-b border-white/10">
              <span className="text-6xl font-light text-white tracking-tight">$50</span>
              <span className="text-gray-500 mb-2 text-sm">per visit</span>
            </div>

            <ul className="space-y-4 mb-10 flex-1">
              {['Exterior wash', 'Interior vacuum', 'Full basic clean', 'Premium foam treatment', 'Glass polishing'].map((feature, i) => (
                <li key={i} className="flex items-center text-gray-300 text-sm gap-3">
                  <Check size={14} className="text-blue-400 shrink-0" />
                  {feature}
                </li>
              ))}
            </ul>

            <a
              href="#booking"
              className="block w-full py-4 text-center text-xs uppercase tracking-[0.2em] font-bold transition-all duration-300 hover:opacity-90"
              style={{
                background: 'linear-gradient(135deg, #1a4fd8 0%, #2563eb 50%, #1e40af 100%)',
                color: '#fff',
                boxShadow: '0 4px 30px rgba(37, 99, 235, 0.4)',
              }}
            >
              Book Premium
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
