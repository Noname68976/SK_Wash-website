import logoImg from '@assets/CE239C07-FC37-4165-BE80-BD9B237563B4_1785751912524.png';

export function Footer() {
  return (
    <footer className="border-t border-white/5 bg-[#020202]">
      <div className="container mx-auto px-6 py-16">
        <div className="flex flex-col md:flex-row justify-between items-start gap-12">

          {/* Brand */}
          <div>
            <img
              src={logoImg}
              alt="SK Wash"
              className="h-20 w-auto mb-4"
              style={{ mixBlendMode: 'screen' }}
            />
            <p className="text-xs uppercase tracking-[0.3em] text-gray-600 mt-2">Premium Car Detailing</p>
          </div>

          {/* Contact */}
          <div className="flex flex-col gap-4">
            <p className="text-[10px] uppercase tracking-[0.3em] text-gray-600 mb-2">Contact</p>
            <a
              href="tel:0477204010"
              className="text-gray-400 text-sm hover:text-blue-400 transition-colors tracking-wider"
            >
              0477 204 010
            </a>
            <a href="#" className="text-gray-400 text-sm hover:text-blue-400 transition-colors tracking-wider uppercase">
              SK Wash
            </a>
          </div>

          {/* Quick links */}
          <div className="flex flex-col gap-4">
            <p className="text-[10px] uppercase tracking-[0.3em] text-gray-600 mb-2">Navigate</p>
            {['About', 'Services', 'Pricing', 'Why Us', 'Book Now'].map((link) => (
              <a
                key={link}
                href={`#${link.toLowerCase().replace(' ', '-')}`}
                className="text-gray-500 text-sm hover:text-white transition-colors tracking-wider"
              >
                {link}
              </a>
            ))}
          </div>
        </div>
      </div>

      <div className="border-t border-white/5">
        <div className="container mx-auto px-6 py-6 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-gray-700">
          <p>&copy; {new Date().getFullYear()} SK Wash. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-gray-400 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-gray-400 transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
