import { motion } from 'framer-motion';

const stats = [
  { value: "100%", label: "Mobile Service" },
  { value: "5★", label: "Quality Standard" },
  { value: "0", label: "Hidden Fees" },
];

export function About() {
  return (
    <section id="about" className="py-28 md:py-36 bg-background relative overflow-hidden">
      {/* Ambient glow */}
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-[500px] h-[500px] bg-blue-900/10 rounded-full blur-[120px] pointer-events-none" />

      <div className="container mx-auto px-6">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <p className="text-xs uppercase tracking-[0.35em] text-blue-400 mb-6">Who We Are</p>
            <h2 className="text-4xl md:text-6xl font-serif mb-10 text-white leading-tight">
              The Standard of <span className="italic text-gray-400">Excellence</span>
            </h2>
            {/* Divider */}
            <div className="flex items-center justify-center gap-4 mb-10">
              <div className="h-[1px] w-16 bg-gradient-to-r from-transparent to-white/20" />
              <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
              <div className="h-[1px] w-16 bg-gradient-to-l from-transparent to-white/20" />
            </div>
            <p className="text-xl md:text-2xl text-gray-400 font-light leading-relaxed max-w-3xl mx-auto">
              SK Wash provides reliable mobile car washing services with uncompromising attention to detail, premium quality products, and the ultimate convenience of service at your home or location.
            </p>
            <p className="mt-6 text-base text-gray-600 font-light italic">
              We don't just wash cars — we restore their presence.
            </p>
          </motion.div>

          {/* Stats row */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="grid grid-cols-3 border border-white/10 divide-x divide-white/10"
          >
            {stats.map((stat, i) => (
              <div key={i} className="py-8 px-6 text-center group relative overflow-hidden">
                <div className="absolute inset-0 bg-blue-600/0 group-hover:bg-blue-600/5 transition-colors duration-500" />
                <div className="text-3xl md:text-4xl font-serif text-white mb-2">{stat.value}</div>
                <div className="text-xs uppercase tracking-[0.2em] text-gray-500">{stat.label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
